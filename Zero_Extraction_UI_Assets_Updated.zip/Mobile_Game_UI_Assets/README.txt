Mobile_Game_UI_Assets

PNG assets cropped from the four supplied reference sheets. Black sheet backgrounds were keyed to transparency. Items absent from the supplied sheets were added from a matching generated icon sheet.

Note: some labels or source icons are repeated in the reference sheets; duplicate variants are suffixed _Alt. These are raster PNGs, not vector/source artwork. Review the crops in-game before production use.
